var http = require('http');
var express = require('express');
var colors = require('colors');
var bodyParser = require('body-parser');

var app = express();
app.use(express.static('./public'));
app.use(bodyParser.urlencoded({ extended: false}))
app.use(bodyParser.json())
app.set('view engine', 'ejs')
app.set('views', './views');

var server = http.createServer(app);
server.listen(80);

console.log('Servidor rodando ...'.rainbow);

app.get('/', function (requisicao, resposta){
resposta.redirect('indexx.html')
})

app.get('/inicio', function (requisicao, resposta){
var nome = requisicao.query.info;
console.log(nome);
})

app.post('/inicio', function (requisicao, resposta){
var data = requisicao.body.data;
console.log(data);
})

app.get('/cadastro',function (requisicao, resposta){
var nome = requisicao.query.nome;
var sobrenome = requisicao.query.sobrenome;
var nascimento = requisicao.query.nascimento;
var civil = requisicao.query.civil;
})
login = app.get('/login',function(requisicao, resposta){
var Usuário = requisicao.query.Usuário
var Senha = requisicao.query.Senha
if (Usuário.requisicao.query.Usuário && nome.requisicao.query.nome)
console.log("Acesso liberado")
resposta.render('status_login.ejs', {Usuário,Senha})



})
cadastro =  app.get('/Cadastro',function(requisicao, resposta){
var nome = requisicao.query.nome
var Senha = requisicao.query.Senha
resposta.render('status_login.ejs', {nome,Senha})

resposta.render('resposta_cadastro', {nome, sobrenome, nascimento, civil})
})
