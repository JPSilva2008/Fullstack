peso = int(input )


