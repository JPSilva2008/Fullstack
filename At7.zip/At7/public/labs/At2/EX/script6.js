function calcular(){

    let entrada =
    document.getElementById("numeros").value;

    let lista = entrada.split(",");

    let soma = 0;
    let maior;
    let menor;
    let pares = 0;
    let somaPares = 0;
    let impares = 0;

    for(let i = 0; i < lista.length; i++){

        let numero = Number(lista[i]);

        soma += numero;

        if(i == 0){
            maior = numero;
            menor = numero;
        }

        if(numero > maior){
            maior = numero;
        }

        if(numero < menor){
            menor = numero;
        }

        if(numero % 2 == 0){
            pares++;
            somaPares += numero;
        }
        else{
            impares++;
        }

    }

    let quantidade = lista.length;

    let media = soma / quantidade;

    let mediaPares = 0;

    if(pares > 0){
        mediaPares = somaPares / pares;
    }

    let porcentagemImpares =
    (impares / quantidade) * 100;

    document.getElementById("resultado").innerHTML =

    "Soma: " + soma + "<br>" +
    "Quantidade: " + quantidade + "<br>" +
    "Média: " + media.toFixed(2) + "<br>" +
    "Maior número: " + maior + "<br>" +
    "Menor número: " + menor + "<br>" +
    "Média dos pares: " + mediaPares.toFixed(2) + "<br>" +
    "Porcentagem de ímpares: " +
    porcentagemImpares.toFixed(2) + "%";

}