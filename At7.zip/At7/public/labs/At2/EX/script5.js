function calcular(){

    let base =
    Number(document.getElementById("base").value);

    let altura =
    Number(document.getElementById("altura").value);

    if(base <= 0 || altura <= 0){

        document.getElementById("resultado").innerHTML =
        "Digite valores maiores que 0!";

        return;
    }

    let area = (base * altura) / 2;

    document.getElementById("resultado").innerHTML =
    "Área do triângulo: " + area;

}