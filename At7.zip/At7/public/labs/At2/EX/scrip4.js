// cria os campos dos 6 alunos
let div = document.getElementById("alunos");

for(let i = 1; i <= 6; i++){

    div.innerHTML += `
    
    <h3>Aluno ${i}</h3>

    Nota 1:
    <input type="number" step="0.1" id="n1_${i}">

    Nota 2:
    <input type="number" step="0.1" id="n2_${i}">

    <br><br>
    
    `;
}

function calcular(){

    let resultado = "";

    for(let i = 1; i <= 6; i++){

        let nota1 =
        Number(document.getElementById(`n1_${i}`).value);

        let nota2 =
        Number(document.getElementById(`n2_${i}`).value);

        let media = (nota1 + nota2) / 2;

        let mensagem = "";

        if(media <= 3){
            mensagem = "Reprovado";
        }
        else if(media <= 7){
            mensagem = "Exame";
        }
        else{
            mensagem = "Aprovado";
        }

        resultado +=
        "Aluno " + i +
        " | Média: " + media.toFixed(1) +
        " | Situação: " + mensagem +
        "<br>";
    }

    document.getElementById("resultado").innerHTML =
    resultado;
}