function ordenar(){

    let i = Number(document.getElementById("i").value);

    let a = Number(document.getElementById("a").value);

    let b = Number(document.getElementById("b").value);

    let c = Number(document.getElementById("c").value);

    let numeros = [a, b, c];

    let resultado = "";

    // ordem crescente
    if(i == 1){

        numeros.sort(function(x, y){
            return x - y;
        });

        resultado = numeros.join(", ");
    }

    // ordem decrescente
    else if(i == 2){

        numeros.sort(function(x, y){
            return y - x;
        });

        resultado = numeros.join(", ");
    }

    // maior no meio
    else if(i == 3){

        numeros.sort(function(x, y){
            return x - y;
        });

        resultado =
        numeros[0] + ", " +
        numeros[2] + ", " +
        numeros[1];
    }

    else{
        resultado = "Valor de I inválido!";
    }

    document.getElementById("resultado").innerHTML =
    "Resultado: " + resultado;

}