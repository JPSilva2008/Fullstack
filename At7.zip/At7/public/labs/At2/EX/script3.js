function classificar(){

    let altura =
    Number(document.getElementById("altura").value);

    let peso =
    Number(document.getElementById("peso").value);

    let classificacao = "";

    // Menor que 1.20
    if(altura < 1.20){

        if(peso <= 60){
            classificacao = "A";
        }
        else if(peso <= 90){
            classificacao = "D";
        }
        else{
            classificacao = "G";
        }

    }

    // Entre 1.20 e 1.70
    else if(altura <= 1.70){

        if(peso <= 60){
            classificacao = "B";
        }
        else if(peso <= 90){
            classificacao = "E";
        }
        else{
            classificacao = "H";
        }

    }

    // Maior que 1.70
    else{

        if(peso <= 60){
            classificacao = "C";
        }
        else if(peso <= 90){
            classificacao = "F";
        }
        else{
            classificacao = "I";
        }

    }

    document.getElementById("resultado").innerHTML =
    "Classificação: " + classificacao;

}