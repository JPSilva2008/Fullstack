function calcular(){

    let trabalho =
    Number(document.getElementById("trabalho").value);

    let avaliacao =
    Number(document.getElementById("avaliacao").value);

    let exame =
    Number(document.getElementById("exame").value);

    let media = (
        (trabalho * 2) +
        (avaliacao * 3) +
        (exame * 5)
    ) / 10;

    document.getElementById("resultado").innerHTML =
    "Média Final: " + media;

}