const mysql = require('mysql2');

const conexao = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'blog'
});

conexao.connect(function(erro){

    if(erro){
        console.log('Erro ao conectar');
    }
    else{
        console.log('Banco conectado');
    }

});

module.exports = conexao;