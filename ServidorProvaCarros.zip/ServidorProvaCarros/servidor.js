const http = require("http");
const express = require('express');
const { render } = require("ejs");
const bodyParser = require('body-parser');
const MongoClient = require("mongodb").MongoClient;

const uri = "mongodb+srv://jpbruca_db_user:FeiSccp2008@cluster0.rxcva4p.mongodb.net/?appName=Cluster0";
const client = new MongoClient(uri);

var app = express();
app.use(express.static('./public'));
app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var dbo, usuarios, carros;

client.connect(function(err) {
    if (err) {
        console.error("Erro ao conectar ao MongoDB:", err);
        return;
    }
    console.log("Conectado ao MongoDB!");
    dbo = client.db("GerenciamentoCarros");
    usuarios = dbo.collection("Usuarios");
    carros = dbo.collection("Carros");

    app.listen(80, () => {
        console.log('Servidor rodando em http://localhost');
    });
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/cadastro.html'); // Alterado para login.html
});

app.get('/index', (req, res) => {
    res.redirect('/gerencia_carros');
});

// --- ROTAS DE USUÁRIOS ---

app.post("/cadastrar_usuario", function(req, resp) {
    let data = { db_nome: req.body.nome, db_login: req.body.login, db_senha: req.body.senha };
    usuarios.insertOne(data, function (err) {
        resp.render('resposta_usuario.ejs', {
            resposta: err ? "Erro ao cadastrar!" : "Usuário cadastrado com sucesso!",
            login: req.body.login
        });
    });
});

app.post("/logar_usuario", function(req, resp) {
    let data = { db_login: req.body.login, db_senha: req.body.senha };
    
    usuarios.find(data).toArray(function(err, items) {
        if (err || items.length == 0) {
            // Caso de falha
            resp.render('resposta_login.ejs', { 
                resposta: "Usuário/senha não encontrado!", 
                logado: false 
            });
        } else {
            // Caso de sucesso
            resp.render('resposta_login.ejs', { 
                resposta: "Logado com sucesso!", 
                logado: true 
            });
        }
    });
});

app.post("/atualizar_usuario", function(req, resp) {
    let filtro = { db_login: req.body.login, db_senha: req.body.senha };
    let novoValor = { $set: { db_senha: req.body.novasenha } };
    usuarios.updateOne(filtro, novoValor, function (err, result) {
        resp.render('resposta_usuario.ejs', {
            resposta: (err || result.modifiedCount == 0) ? "Erro ao atualizar!" : "Atualizado com sucesso!",
            login: req.body.login
        });
    });
});

// --- ROTAS DE CARROS ---

app.get('/gerencia_carros', function(req, res) {
    let login = req.query.login || '';
    carros.find({ dono: login }).toArray(function(err, items) {
        res.render('gerencia_carros.ejs', { carros: items || [], login_do_usuario: login });
    });
});

app.post('/adicionar_carro', function(req, res) {
    let novoCarro = { 
        marca: req.body.marca, 
        modelo: req.body.modelo, 
        ano: parseInt(req.body.ano), 
        qtde_disponivel: parseInt(req.body.qtde),
        dono: req.body.dono 
    };
    carros.insertOne(novoCarro, function(err) {
        res.redirect('/gerencia_carros?login=' + req.body.dono);
    });
});

app.post('/deletar_carro', function(req, res) {
    carros.deleteOne({ modelo: req.body.modelo }, function(err, result) {
        res.redirect('/gerencia_carros?login=' + req.body.dono);
    });
});

app.post('/vender_carro', function(req, res) {
    carros.updateOne({ modelo: req.body.modelo }, { $inc: { qtde_disponivel: -1 } }, function(err, result) {
        res.redirect('/gerencia_carros?login=' + req.body.dono);
    });
});